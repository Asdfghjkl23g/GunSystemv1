# 🎯 วิธี Compile ปลั๊กอิน GunSystem

## 📋 เนื่องจากข้อจำกัดของระบบออนไลน์

ผมไม่สามารถ compile ไฟล์ JAR ให้คุณได้โดยตรงในตอนนี้ เนื่องจาก:
- ระบบไม่มี Java JDK ติดตั้ง
- ไม่สามารถดาวน์โหลด dependencies ได้
- ข้อจำกัดด้านเครือข่าย

---

## ✅ วิธีแก้ปัญหา: 3 ทางเลือก

### 🏆 ทางเลือกที่ 1: ใช้ GitHub Actions (แนะนำสุด - ฟรี 100%)

1. **สร้างบัญชี GitHub** (ถ้ายังไม่มี):
   - ไปที่ https://github.com/signup
   - สมัครสมาชิกฟรี

2. **สร้าง Repository ใหม่:**
   - กด "+" มุมบนขวา → "New repository"
   - ตั้งชื่อ: `GunSystem`
   - กด "Create repository"

3. **อัพโหลดโค้ด:**
   - กด "uploading an existing file"
   - ลากไฟล์ทั้งหมดในโฟลเดอร์ GunSystem ไปวาง
   - กด "Commit changes"

4. **สร้างไฟล์ GitHub Actions:**
   - ใน Repository ของคุณ สร้างไฟล์: `.github/workflows/build.yml`
   - วางโค้ดด้านล่างนี้:

```yaml
name: Build Plugin

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up JDK 17
      uses: actions/setup-java@v3
      with:
        java-version: '17'
        distribution: 'temurin'
        cache: maven
    
    - name: Build with Maven
      run: mvn clean package
    
    - name: Upload JAR
      uses: actions/upload-artifact@v3
      with:
        name: GunSystem-Plugin
        path: target/*.jar
```

5. **รันการ Build:**
   - ไปที่แท็บ "Actions"
   - กด "Run workflow"
   - รอ 2-3 นาที
   - ดาวน์โหลดไฟล์ JAR จาก "Artifacts"

---

### 🥈 ทางเลือกที่ 2: ใช้ Gitpod (ออนไลน์ - ฟรี 50 ชม./เดือน)

1. **ไปที่:** https://gitpod.io
2. **เชื่อมต่อกับ GitHub**
3. **เปิด Repository ของคุณใน Gitpod**
4. **พิมพ์คำสั่ง:**
```bash
mvn clean package
```
5. **ดาวน์โหลดไฟล์:** `target/GunSystem-1.0.0.jar`

---

### 🥉 ทางเลือกที่ 3: Compile บนคอมพิวเตอร์ (Windows/Mac/Linux)

#### สำหรับ Windows:

1. **ดาวน์โหลด Java 17:**
   - https://adoptium.net/temurin/releases/
   - เลือก JDK 17 (LTS)
   - ติดตั้งตามปกติ

2. **ดาวน์โหลด Maven:**
   - https://maven.apache.org/download.cgi
   - แตกไฟล์ใส่ `C:\Program Files\Maven`
   - เพิ่ม Path: `C:\Program Files\Maven\bin`

3. **เปิด Command Prompt:**
```cmd
cd path\to\GunSystem
mvn clean package
```

4. **ไฟล์ JAR อยู่ที่:** `target\GunSystem-1.0.0.jar`

---

#### สำหรับ Mac:

```bash
# ติดตั้ง Homebrew (ถ้ายังไม่มี)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# ติดตั้ง Java และ Maven
brew install openjdk@17
brew install maven

# Compile
cd /path/to/GunSystem
mvn clean package
```

---

#### สำหรับ Linux (Ubuntu/Debian):

```bash
# ติดตั้ง Java และ Maven
sudo apt update
sudo apt install openjdk-17-jdk maven

# Compile
cd /path/to/GunSystem
mvn clean package
```

---

### 📱 ทางเลือกที่ 4: ใช้มือถือ Android (Termux)

```bash
# ติดตั้ง Termux จาก F-Droid
# https://f-droid.org/packages/com.termux/

# เปิด Termux แล้วพิมพ์:
pkg update && pkg upgrade
pkg install openjdk-17 maven unzip
termux-setup-storage

# ย้ายไฟล์ GunSystem.zip ไปที่ Downloads
cd storage/downloads
unzip GunSystem.zip
cd GunSystem
mvn clean package

# ไฟล์ JAR จะอยู่ที่ target/
```

---

## 🎁 ผลลัพธ์ที่คุณจะได้

หลังจาก compile สำเร็จ คุณจะได้:
```
target/
  └── GunSystem-1.0.0.jar  ← ไฟล์นี้!
```

**ขนาดประมาณ:** 20-30 KB

---

## 📦 วิธีติดตั้งในเซิร์ฟเวอร์

1. คัดลอก `GunSystem-1.0.0.jar`
2. วางในโฟลเดอร์ `plugins/` ของเซิร์ฟเวอร์
3. รีสตาร์ทเซิร์ฟเวอร์
4. พิมพ์ `/gun` เพื่อเริ่มใช้งาน!

---

## ❓ ถ้ายังติดปัญหา

ติดต่อผ่าน:
- GitHub Issues
- Discord: Spigot/Paper Community
- SpigotMC Forums

---

## 🌟 ทำไมต้อง Compile เอง?

- ✅ **ปลอดภัย** - ไม่ต้องกังวลเรื่อง malware
- ✅ **เรียนรู้** - เข้าใจ development workflow
- ✅ **ปรับแต่ง** - แก้โค้ดได้เอง
- ✅ **อัพเดท** - ใช้เวอร์ชันล่าสุดเสมอ

---

## 💡 Bonus: ใช้ Online Build Service

ถ้าไม่อยากยุ่งยาก ลองเว็บพวกนี้:
- **Jitpack.io** - Build จาก GitHub repo
- **Travis CI** - Free tier มีให้
- **CircleCI** - รองรับ Maven

---

**สรุป:** วิธีที่ง่ายและแนะนำที่สุดคือ **GitHub Actions** ครับ!
ไม่ต้องติดตั้งอะไรเลย แค่อัพโหลดโค้ดแล้วรอรับไฟล์ JAR 🎉
